# Money Ready — Loudoun 4-H · Interactive Toolkit

**Turn financial literacy lessons into live, student-led learning moments.**

A student-led prototype that makes Loudoun 4-H Teens-as-Teachers
and workshop content more interactive, practical, and measurable.

> **Status:** Proposed pilot · Concept for discussion · Student-led prototype ·
> Designed to support Teens-as-Teachers–style workshops · **Pending review and
> approval by Loudoun 4-H** · Built around existing financial-literacy
> topics · **Educational only** · **Privacy-safe by design**

---

## What it is

A single-page web app (no accounts, no backend, no tracking) that gives a
workshop a repeatable flow: **pick a module → run a live challenge → students
vote → reveal the best answer → discuss → send a take-home card.** It is built
so a nervous teen volunteer can teach with confidence and so students
*participate* instead of passively listening.

## Screens

| Screen | What it does |
| --- | --- |
| **Landing** | Mission, the "why," how it works, sample modules, pilot plan |
| **Module library** | 10 ready-made modules with grade band, length, key concept, activity type, and materials |
| **Lesson transformation** | Shows how a static lesson becomes an interactive one |
| **Student challenge** | Live scenario with timer, round, room code, A–D answers, optional team score |
| **Reveal** | Best answer, why it works, key concept, common trap, discussion prompt, apply-it |
| **Facilitator dashboard** | Current module, room code, students joined, live class results, discussion prompt, next-activity, shared-screen/hotseat, downloadable exit-ticket summary |
| **Volunteer prep** | Opening script, vocabulary, timed steps, prompts, printables, practice mode |
| **Toolkit builder** | Guided workflow that assembles a full packet (deck outline, practice notes, parent letter, admin packet, event checklist, sign-up form, reflection page) |
| **Request / partner portal** | Teachers request a volunteer; partners offer support (copy-ready summaries, nothing is sent) |
| **Standards helper** | Retrieval-only Q&A grounded in a small set of approved-style resources — it never freestyles |
| **Impact snapshot** | Example/placeholder metrics + a real, on-device, privacy-safe measurement panel |
| **Take-home card** | Fridge-friendly, dignified, printable family activity |

### The 10 modules
Needs vs. Wants · Budget Battle · Save or Spend? · Credit Climb · Paycheck
Puzzle · Smart Shopping Challenge · Fraud & Red Flags · Banking Basics ·
College Cost Choices · Investing Mythbusters.

## Privacy-safe by design

- **No names, no logins, no personal data.** There is no backend server.
- Any metric a volunteer records (e.g. an anonymous confidence tap) is an
  **aggregate count** stored **only in that browser** via `localStorage`, and
  can be cleared with one button.
- All impact numbers shown in the app are clearly **labeled as examples /
  placeholders**.
- No external fonts, scripts, or requests — the app also works offline.

## Run it locally

It's plain HTML/CSS/JS — just open it, or serve the folder:

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Hosting

Because it's fully static, it can be published for free on **GitHub Pages**
(Settings → Pages → deploy from branch). Nothing else is required.

## Project structure

```
index.html            App shell, header, footer
assets/css/styles.css Design system (warm, credible, nonprofit-ready)
assets/js/data.js     All module content — safe for non-coders to edit
assets/js/metrics.js  Privacy-safe, aggregate-only local metrics
assets/js/app.js      Hash router + all screens
```

## Disclaimer

This is a student-built prototype and a **concept for discussion**. It is
**educational only**, is **not financial advice**, and is designed to support —
**pending review and approval** — Loudoun 4-H's Teens-as-Teachers–style
workshops. Module content is illustrative and built around existing
financial-literacy topics; the standards helper's sources are examples that a
full version would replace with approved resources.
